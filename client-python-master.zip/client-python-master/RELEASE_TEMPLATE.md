PyPI package: https://pypi.org/project/grakn-client
Documentation: https://dev.grakn.ai/docs/client-api/python

### Distribution

Available through https://pypi.org
```
pip install grakn-client
```
Or you can upgrade your local installation with:
```
pip install -U grakn-client
```

{ release notes }
